export default {
    apiKey: "AIzaSyDS-VBAP05ZL-QP-6yBACla5G9FtRlYl3o",
    authDomain: "whatsappclone-4e80f.firebaseapp.com",
    databaseURL: "https://whatsappclone-4e80f.firebaseio.com",
    projectId: "whatsappclone-4e80f",
    storageBucket: "whatsappclone-4e80f.appspot.com",
    messagingSenderId: "947257788451",
    appId: "1:947257788451:web:85b68a569d184d864d4996"
};